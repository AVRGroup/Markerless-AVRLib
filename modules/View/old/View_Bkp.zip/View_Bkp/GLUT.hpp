#ifndef AVR_GLUT_HPP
#define AVR_GLUT_HPP

#include "Window.hpp"

#include <GL/freeglut.h>

namespace avr {

class GlutWindow : public Window {
public:
   virtual ~GlutWindow();

   Size2i GetSize() const;
   Point2i GetPosition() const;
   std::string GetLabel() const { return label; }
   bool isActive() const { return active; }

   void SetSize(const Size2i&);
   void SetPosition(const Point2i&);
   void SetLabel(const std::string& label);
//   void SetUpdateFunction(UpdateFunc);

private:
   GlutWindow(const std::string& label);

   void Destroy();

private:
   bool active;
   std::string label;

   static struct Initializer {
      Initializer();
   } initialize;

   friend class WindowManager;
   friend class GlutWindowBuilder;

   typedef Window Super;
};

class GlutWindowBuilder : public Window::Builder {
private:
   const string label;

public:
   GlutWindowBuilder(const string& label) : label(label) {/* ctor */}

   SPtr<Window> build() const {
      return new GlutWindow(label);
   }
};

} // namespace avr

#endif // AVR_GLUT_HPP
