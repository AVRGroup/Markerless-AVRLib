#include "Window.hpp"

// TEMP
#include <GL/freeglut.h>

namespace avr {

WindowManager::Initializer WindowManager::initialize;
std::vector<SPtr<Window> > WindowManager::windows;
size_t WindowManager::count;

WindowManager::Initializer::Initializer() {
//   glutIdleFunc(WindowManager::IdleCallback);
   windows.reserve(8);
   count = 0;
}

void WindowManager::Initializer::SetCallbacks(size_t id) {
   glutSetWindow(id);
   // keyboard callbacks
   glutKeyboardFunc(KeyboardCallback);
   glutKeyboardUpFunc(KeyboardUpCallback);
   glutSpecialFunc(SpecialKeyCallback);
   glutSpecialUpFunc(SpecialKeyUpCallback);
   // mouse callbacks
   glutMouseFunc(MouseClickCallback);
   glutMotionFunc(ClickedCursorMotionCallback);
   glutPassiveMotionFunc(CursorMotionCallback);
   // others callbacks
//   glutEntryFunc(EntryCallback);
   glutReshapeFunc(ReshapeCallback);
   glutDisplayFunc(DisplayCallback);
}

SPtr<Window> WindowManager::Create(const Window::Builder& win) {
   windows.push_back(win.build()); count++;
   size_t idx = windows.size() - 1;
   windows[idx]->index = idx;
   initialize.SetCallbacks(windows[idx]->GetID());
   return windows[idx];
}

void WindowManager::Destroy(SPtr<Window>& win) {
   if(not win.Null()) {
      windows[win->index] = nullptr; count--;
      win->Destroy();
   }
}

void WindowManager::Destroy(size_t index) {
   SPtr<Window> win = windows[index];
   if(not win.Null()) {
      windows[index] = nullptr; count--;
      win->Destroy();
   }
}

/// Callbacks
// C�digo Geral
//    Obt�m id da janela atual
//    Busca instancia da janela na cole��o
//    Chama evento correpondente
void WindowManager::KeyboardCallback(uchar key, int, int) {
   auto& win = windows[glutGetWindow() - 1];
   if(not win.Null() && win->hasListener())
      win->GetListener()->KeyboardEvent(Key(key, Key::DOWN));
   else if(not win.Null()){
      switch(key) {
      case Key::ESQ:
         Destroy(win);
         if(count == 0)
            exit(EXIT_SUCCESS);
      }
   }
}
void WindowManager::KeyboardUpCallback(uchar key, int, int) {
   auto& win = windows[glutGetWindow() - 1];
   if(not win.Null() && win->hasListener())
      win->GetListener()->KeyboardEvent(Key(key, Key::UP));
}
void WindowManager::SpecialKeyCallback(int key, int, int) {
   cout << key << "\n";
   auto& win = windows[glutGetWindow() - 1];
   if(not win.Null() && win->hasListener())
      win->GetListener()->SpecialKeyEvent(SpecialKey(key, SpecialKey::DOWN));
}
void WindowManager::SpecialKeyUpCallback(int key, int, int) {
   auto& win = windows[glutGetWindow() - 1];
   if(not win.Null() && win->hasListener())
      win->GetListener()->SpecialKeyEvent(SpecialKey(key, SpecialKey::UP));
}
void WindowManager::MouseClickCallback(int button, int state, int x, int y) {
   auto& win = windows[glutGetWindow() - 1];
   if(not win.Null() && win->hasListener())
      win->GetListener()->MouseClickEvent(MouseButton(MBButton(button), MBState(state)), Point2i(x, y));
}
void WindowManager::CursorMotionCallback(int x, int y) {
   auto& win = windows[glutGetWindow() - 1];
   if(not win.Null() && win->hasListener())
      win->GetListener()->CursorMotionEvent(Point2i(x, y), false);
}
void WindowManager::ClickedCursorMotionCallback(int x, int y) {
   auto& win = windows[glutGetWindow() - 1];
   if(not win.Null() && win->hasListener())
      win->GetListener()->CursorMotionEvent(Point2i(x, y), true);
}
void WindowManager::ReshapeCallback(int width, int height) {
   auto& win = windows[glutGetWindow() - 1];
   if(not win.Null() && win->hasListener())
      win->GetListener()->ReshapeEvent(Size2i(width, height));
}
void WindowManager::EntryCallback(int state) {
//   auto& win = windows[glutGetWindow() - 1];
//   if (not win.Null())
//      win->active = (state == GLUT_ENTERED);
}
void WindowManager::DisplayCallback() {
   auto& win = windows[glutGetWindow() - 1];
   if(not win.Null() && win->hasRenderer())
      win->GetRenderer()->Render();
}

void WindowManager::IdleCallback() {
//   for(auto& win : WindowManager::windows) {
//      if(win.Null()) continue;
//      if(updateFunc)
//         updateFunc(*win);
//      glutSetWindow(win->GetID());
//      glutPostRedisplay();
//   }
}

} // namespace avr
