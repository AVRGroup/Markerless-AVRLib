#ifndef AVR_WINDOW_HPP
#define AVR_WINDOW_HPP

#include <avr/core/Core.hpp>

#include "EventListener.hpp"
#include "Renderer.hpp"

namespace avr {

class Window;
class WindowManager;

using ReshapeFunc = void(*)(const Size2i&);
using UpdateFunc  = void(*)(Window&);

class Window {
public:
   typedef size_t IDType;

   virtual ~Window() {/* dtor */}

   virtual bool isActive() const = 0;
   virtual Size2i GetSize() const = 0;
   virtual Point2i GetPosition() const = 0;

   virtual void SetSize(const Size2i&) = 0;
   virtual void SetPosition(const Point2i&) = 0;

   IDType GetID() const { return id; }
   SPtr<Renderer> GetRenderer() const { return renderer; }
   SPtr<EventListener> GetListener() const { return listener; }
   bool hasListener() const { return (not listener.Null()); }
   bool hasRenderer() const { return (not renderer.Null()); }

   void SetListener(const SPtr<EventListener>& listener) { this->listener = listener; }
   void SetRenderer(const SPtr<Renderer>& renderer) { this->renderer = renderer; }

   class Builder : public avr::Builder<Window> {
   public:
      virtual ~Builder() {/* dtor */}
      virtual SPtr<Window> build() const = 0;
   };

protected:
   Window(const IDType& id) : id(id), listener(0x0), renderer(0x0) {/* ctor */}

   virtual void Destroy() = 0;

private:
   IDType id;
   size_t index;
   SPtr<EventListener> listener;
   SPtr<Renderer> renderer;

   friend class WindowManager;
};

class WindowManager {
public:
   typedef std::vector<SPtr<Window> >::iterator Iterator;

   static SPtr<Window> Create(const Window::Builder&);
   static void Destroy(SPtr<Window>&);
   static void Destroy(size_t index);

   static size_t NumberOfWindows()        { return count; }
   static SPtr<Window> Get(size_t index)  { return windows[index]; }

   WindowManager() = delete;
   WindowManager(const WindowManager&) = delete;
   WindowManager& operator = (const WindowManager&) = delete;

private:
   static size_t count;
   static std::vector<SPtr<Window> > windows;

   static struct Initializer {
      Initializer();
      void SetCallbacks(size_t);
   } initialize;

   // Keyboard callbacks
   static void KeyboardCallback(uchar, int, int);
   static void KeyboardUpCallback(uchar, int, int);
   static void SpecialKeyCallback(int, int, int);
   static void SpecialKeyUpCallback(int, int, int);
   // Mouse callbacks
   static void MouseClickCallback(int, int, int, int);
   static void CursorMotionCallback(int, int);
   static void ClickedCursorMotionCallback(int, int);
   // Others callbacks
   static void ReshapeCallback(int, int);
   static void EntryCallback(int);
   static void DisplayCallback();
   static void IdleCallback();
};

} // namespace avr

#endif // AVR_WINDOW_HPP
