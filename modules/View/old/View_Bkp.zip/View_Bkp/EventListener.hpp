#ifndef AVR_EVENT_LISTENER_HPP
#define AVR_EVENT_LISTENER_HPP

#include <avr/core/Core.hpp>

namespace avr {

struct MouseButton;
struct SpecialKey;
struct Key;

class EventListener {
public:
   virtual ~EventListener() {/* dtor */}

   virtual void KeyboardEvent(const Key&) = 0;
   virtual void SpecialKeyEvent(const SpecialKey&) = 0;
   virtual void CursorMotionEvent(const Point2i& pos, bool clicked) = 0;
   virtual void MouseClickEvent(const MouseButton&, const Point2i& pos) = 0;
   virtual void ReshapeEvent(const Size2i&) = 0;
};

/*
 * Special structures
 */
struct MouseButton {
   enum Button { LEFT, MIDDLE, RIGHT };
   enum State { DOWN, UP };

   Button button;
   State state;

   MouseButton(Button button, State state = UP) : button(button), state(state) {/* ctor */}

   bool isDown() const { return (state == DOWN); }
   bool isUp() const { return (state == UP); }

   bool operator == (const Button& b) const { return (button == b); }
   bool operator != (const Button& b) const { return (button != b); }
};

typedef MouseButton::Button MBButton;
typedef MouseButton::State  MBState;

struct SpecialKey {
   enum KeyCod { F1 = 0x01, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12,
               ARROW_LEFT = 0x64, ARROW_UP, ARROW_RIGHT, ARROW_DOWN,
               PAGE_UP = 0x68, PAGE_DOWN, HOME, END, INSERT,
               LEFT_SHIFT = 0x70, RIGHT_SHIFT, LEFT_CTRL, RIGHT_CTRL, LEFT_ALT, ALTGR };
   enum State { DOWN, UP };

   KeyCod code;
   State state;

   SpecialKey(int key, State state = UP) : code(KeyCod(code)), state(state) {/* ctor */}

   bool isDown() const { return (state == DOWN); }
   bool isUp() const { return (state == UP); }

   bool operator == (const KeyCod& cod) const { return (code == cod); }
   bool operator != (const KeyCod& cod) const { return (code != cod); }
};

typedef SpecialKey::KeyCod SKKeyCod;
typedef SpecialKey::State  SKState;

struct Key {
   enum KeyCod { BACKSPACE = 0x08, TAB = 0x09, ENTER = 0x0D, PAUSE_BREAK = 0x13,
               CAPSLOCK = 0x14, ESQ = 0x1B, SPACE = 0x20, PRINT_SCREEN = 0x2C,
               DEL = 0x7F, NUMLOCK = 0x90, SCROLLOCK = 0x91 };

   enum State { DOWN, UP };

   unsigned char key;
   State state;

   Key(unsigned char key, State state = UP) : key(key), state(state) {/* ctor */}

   bool isDown() const { return (state == DOWN); }
   bool isUp() const { return (state == UP); }

   bool isLetter() const { return ('A' <= key && key <= 'Z') || ('a' <= key && key <= 'z'); }
   bool isNumber() const { return ('0' <= key && key <= '9'); }
   bool isAlpha() const { return (isLetter() || isNumber()); }

   bool operator == (const KeyCod& cod) const { return (key == cod); }
   bool operator != (const KeyCod& cod) const { return (key != cod); }
   bool operator == (char c) const { return (key == c); }
   bool operator != (char c) const { return (key != c); }
   bool operator <= (char c) const { return (key <= c); }
   bool operator >= (char c) const { return (key >= c); }
   bool operator <  (char c) const { return (key <  c); }
   bool operator >  (char c) const { return (key >  c); }

   operator unsigned char() const { return key; }
};

typedef Key::KeyCod KKeyCod;
typedef Key::State  KState;

} // namespace avr

#endif // AVR_EVENT_LISTENER_HPP
