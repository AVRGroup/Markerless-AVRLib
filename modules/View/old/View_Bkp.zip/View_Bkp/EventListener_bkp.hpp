#ifndef AVR_EVENT_LISTENER_TEMP_HPP
#define AVR_EVENT_LISTENER_TEMP_HPP

#include <avr/core/Core.hpp>

namespace avr {



} // namespace avr

#endif // AVR_EVENT_LISTENER_HPP
