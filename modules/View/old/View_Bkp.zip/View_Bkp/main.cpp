#include <algorithm>
#include <iostream>
#include <vector>

#include "EventListener.hpp"
#include "GLUT.hpp"

using namespace std;

float var = 0;
float dir = 1;
bool idleOn[] = {true, true, true};

void init (void);
void idle();
void update(avr::Window&);

using namespace avr;

using std::cout;
using std::endl;

class TesteListener : public EventListener {
private:
   SPtr<Window> win;
public:
   TesteListener(SPtr<Window>& win) : win(win) {/* ctor */}

   void KeyboardEvent(const Key& key) {
      if(key.isDown())
         if(key == Key::ESQ) {
            idleOn[win->GetID()-1] = false;
            WindowManager::Destroy(win);
            if(WindowManager::NumberOfWindows() == 0) {
               glutLeaveMainLoop();
            }
         }
   }
   void SpecialKeyEvent(const SpecialKey& key) {
//      cout << "SpecialKeyEvent: Janela " << win->GetID() << endl;
   }
   void CursorMotionEvent(const Point2i& pos, bool clicked) {
//      cout << "CursorMotionEvent: Janela " << win->GetID() << endl;
   }
   void MouseClickEvent(const MouseButton& btn, const Point2i& pos) {
//      cout << "MouseClickEvent: Janela " << win->GetID() << endl;
   }
   void ReshapeEvent(const Size2i& size) {
//      cout << "ReshapeEvent: Janela " << win->GetID() << endl;
   }
};

class TesteRenderer : public Renderer {
public:
   void Render() {
      // Limpar todos os pixels
      glClear (GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

      glColor3f (1.0, 0.0, 0.0);
      glBegin(GL_POLYGON);
         glVertex2f (-1.0, -1.0);
         glVertex2f (1.0, -1.0);
         glColor3f (1.0, 1.0, 0.0);
         glVertex2f (-1.0, var);
      glEnd();
      glutSwapBuffers ();
   }
};

void draw() {
   // Limpar todos os pixels
      glClear (GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

      glColor3f (1.0, 0.0, 0.0);
      glBegin(GL_POLYGON);
         glVertex2f (-1.0, -1.0);
         glVertex2f (1.0, -1.0);
         glColor3f (1.0, 1.0, 0.0);
         glVertex2f (-1.0, var);
      glEnd();
      glutSwapBuffers ();
}

/**
   Tarefas:
   - Fazer a WindowManager
   - N�o acho que d� tempo para mais alguma coisa, ent�o se der pense se h� algo mais para ser feito!!
*/



int main(int argc, char* argv[]) {
   for(uint i = 0; i < 3; i++) {
      SPtr<Window> window = WindowManager::Create(GlutWindowBuilder(avr::format("Janela %d", i)));
      window->SetListener(new TesteListener(window));
      window->SetRenderer(new TesteRenderer);
   }

//   glutIdleFunc(idle);
   init();

   glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_CONTINUE_EXECUTION);
   glutMainLoop();

   return 0;
}

void update(avr::Window& win) {
   if(var <= -1.0 || var >= 1.0) dir *= -1;
   var += dir * 0.005;
}

void idle()
{
   bool idleOff = !idleOn[0] && !idleOn[1] && !idleOn[2];
   if(idleOff) return;

   if(var <= -1.0 || var >= 1.0) dir *= -1;
   var += dir * 0.005;

   for(size_t i = 1; i <= 3; i++) {
      if(!idleOn[i-1]) continue;
      glutSetWindow(i);
      glutPostRedisplay();
   }
}

void init (void)
{
   // selecionar cor de fundo (preto)
   glClearColor (0.0, 0.0, 0.0, 0.0);

   // inicializar sistema de viz.
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-1.0, 1.0, -1.0, 1.0, -2.0, 20.0);

   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}
