#include "GLUT.hpp"

namespace avr {

using std::string;
using std::vector;

GlutWindow::Initializer GlutWindow::initialize;

GlutWindow::Initializer::Initializer() {
   int argc = 0;
   glutInit(&argc, 0x0);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGBA);
   glutInitWindowPosition(20, 20);
   glutInitWindowSize(640, 480);
}

GlutWindow::GlutWindow(const string& label) : Super(glutCreateWindow(label.c_str())), active(false), label(label) {
   /* ctor */
}

GlutWindow::~GlutWindow() {
   // ...
}

void GlutWindow::Destroy() {
   size_t id = Super::GetID();
   glutDestroyWindow(id);
}

Size2i GlutWindow::GetSize() const {
   return Size2i(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
}
Point2i GlutWindow::GetPosition() const {
   return Point2i(glutGet(GLUT_WINDOW_X), glutGet(GLUT_WINDOW_Y));
}

void GlutWindow::SetSize(const Size2i& s) {
   glutReshapeWindow(s.width, s.height);
}
void GlutWindow::SetPosition(const Point2i& p) {
   glutPositionWindow(p.x, p.y);
}

//static UpdateFunc updateFunc = 0x0;
//void GlutWindow::SetUpdateFunction(UpdateFunc update) {
//   updateFunc = update;
//}
void GlutWindow::SetLabel(const std::string& label) {
   this->label = label;
   glutSetWindowTitle(label.c_str());
}

} // namespace avr
