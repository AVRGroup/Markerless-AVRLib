#include <opencv2/calib3d/calib3d.hpp>
#include <opencv2/core/core.hpp>

#include "Trackers.hpp"

#define TH_GOOD_MATCHES       20
#define WINDOWS_BORDER_SIZE   50

avr::Frame avr::TrackingSystem::prev;
std::vector<cv::Point2f> avr::TrackingSystem::fTracked;
std::vector<cv::Point2f> avr::TrackingSystem::mTracked;

namespace avr {

/**-----------------------------------------------------------------------------------------------------------------------------------------------**\
*                                                        FeatureTracker                                                                             *
\**-----------------------------------------------------------------------------------------------------------------------------------------------**/

FeatureTracker::FeatureTracker(OptFlag flag) : TrackingSystem() {
   switch(flag) {
   case avr::OPT_BALANCING:
      this->detector = new SIFTDetector;
      this->extractor = new BRISKExtractor;
      this->matcher = new BruteForceMatcher(cv::NORM_HAMMING);
      break;

   case avr::OPT_PERFORMANCE:
      this->detector = new STARDetector;
      this->extractor = new SURFExtractor;
      this->matcher = new BruteForceMatcher(cv::NORM_L1);
      break;

   case avr::OPT_QUALITY:
      this->detector = new SIFTDetector;
      this->extractor = new SIFTExtractor;
      this->matcher = new BruteForceMatcher(cv::NORM_L2);
      break;
   }
}

FeatureTracker::FeatureTracker(const SPtr<FeatureDetector>& d, const SPtr<DescriptorExtractor>& e, const SPtr<DescriptorMatcher>& m) : TrackingSystem() {
   this->detector = d;
   this->extractor = e;
   this->matcher = m;
}

void FeatureTracker::Track(Marker& _target, Frame& scene, Corners& out) {
   NaturalMarker& target = dynamic_cast<NaturalMarker&>(_target);
   TrackingSystem::prev = scene;

   vector<cv::Point2f>& targetPoints = TrackingSystem::mTracked;
   vector<cv::Point2f>& scenePoints = TrackingSystem::fTracked;
   targetPoints.clear(); scenePoints.clear();

   if(scene.descriptors.empty()) {
      // TODO Fazer o corte do frame
      Mat sceneImage = (!target.region) ? scene.image : scene.image(target.region.Get());
      (*this->detector)(scene.image, scene.keypoints);
      (*this->extractor)(scene.image, scene.keypoints, scene.descriptors);
   }

   vector<cv::DMatch> matches;
   (*this->matcher)(target.descriptors, scene.descriptors, matches);

   for(auto it : matches) {
      targetPoints.push_back(target.keypoints[it.queryIdx].pt);
      scenePoints.push_back(scene.keypoints[it.trainIdx].pt);
   }

#ifdef DEBUG_
   cout << "init: " << scenePoints.size() << endl;
#endif // DEBUG_

   // TODO Definir modo do marcador
   if(matches.size() >= TH_GOOD_MATCHES)
      target.SetLost(false);
   else {
      target.SetLost(true);
      return;
   }

   vector<cv::Point2f> targetCorner(4);
   targetCorner[0] = cv::Point2f(0.0, 0.0);
   targetCorner[1] = cv::Point2f(target.size.width, 0.0);
   targetCorner[2] = cv::Point2f(target.size.width, target.size.height);
   targetCorner[3] = cv::Point2f(0.0, target.size.height);

   Mat H = cv::findHomography(targetPoints, scenePoints, cv::RANSAC, 4);
   cv::perspectiveTransform(targetCorner, out, H);

   for(auto p : scenePoints) {
      cv::circle(scene.image, p, 5, cv::Scalar(0, 0, 255), -1);
   }

   // TODO Definir o campo region do marcador
   cv::Point2f min(1 << 30, 1 << 30);
   cv::Point2f max(1 >> 30, 1 >> 30);
   for(auto it : out){
      if(it.x < min.x) min.x = it.x;
      else if(it.x > max.x) max.x = it.x;

      if(it.y < min.y) min.y = it.y;
      else if(it.y > max.y) max.y = it.y;
   }

   const cv::Rect& rect = target.GetRegion().Get();
   cv::line(scene.image, Point2f(rect.x, rect.y), Point2f(rect.x + rect.width, rect.y), cv::Scalar(255, 0, 0), 4);
   cv::line(scene.image, Point2f(rect.x + rect.width, rect.y), Point2f(rect.x + rect.width, rect.y + rect.height), cv::Scalar(255, 0, 0), 4);
   cv::line(scene.image, Point2f(rect.x + rect.width, rect.y + rect.height), Point2f(rect.x, rect.y + rect.height), cv::Scalar(255, 0, 0), 4);
   cv::line(scene.image, Point2f(rect.x, rect.y + rect.height), Point2f(rect.x, rect.y), cv::Scalar(255, 0, 0), 4);

   cv::Point2f border(WINDOWS_BORDER_SIZE, WINDOWS_BORDER_SIZE);
   min -= border; max += border;
   if(min.x < 0) min.x = 0;
   if(min.y < 0) min.y = 0;
   if(max.x > scene.image.cols) max.x = scene.image.cols;
   if(max.y > scene.image.rows) max.y = scene.image.rows;

   target.SetRegion(avr::BRect<int>(min, max));
}

/**-----------------------------------------------------------------------------------------------------------------------------------------------**\
*                                                         MotionTracker                                                                             *
\**-----------------------------------------------------------------------------------------------------------------------------------------------**/

MotionTracker::MotionTracker(OptFlag) : TrackingSystem() {
   this->tracker = new LukasKanadeAlgorithm;
}

MotionTracker::MotionTracker(const SPtr<OpticFlowAlgorithm>& _tracker) : TrackingSystem(), tracker(_tracker) {/* ctor */}

void MotionTracker::Track(Marker& _target, Frame& scene, Corners& out) {
   NaturalMarker& target = dynamic_cast<NaturalMarker&>(_target);
   vector<cv::Point2f>& targetPoints = TrackingSystem::mTracked;
   vector<cv::Point2f>& scenePoints = TrackingSystem::fTracked;

   (*this->tracker)(TrackingSystem::prev.image, scenePoints, scene.image, scenePoints, targetPoints);

   if(scenePoints.size() >= TH_GOOD_MATCHES)
      target.SetLost(false);
   else {
      target.SetLost(true);
      return;
   }

   vector<cv::Point2f> targetCorner(4);
   targetCorner[0] = cv::Point2f(0.0, 0.0);
   targetCorner[1] = cv::Point2f(target.size.width, 0.0);
   targetCorner[2] = cv::Point2f(target.size.width, target.size.height);
   targetCorner[3] = cv::Point2f(0.0, target.size.height);

   Mat H = cv::findHomography(targetPoints, scenePoints, cv::RANSAC, 4);
   cv::perspectiveTransform(targetCorner, out, H);

   for(auto p : scenePoints) {
      cv::circle(scene.image, p, 3, cv::Scalar(0, 255, 0), -1);
   }

   // TODO Definir o campo region do marcador
   cv::Point2f min(1 << 30, 1 << 30);
   cv::Point2f max(1 >> 30, 1 >> 30);
   for(auto it : out){
      if(it.x < min.x) min.x = it.x;
      else if(it.x > max.x) max.x = it.x;

      if(it.y < min.y) min.y = it.y;
      else if(it.y > max.y) max.y = it.y;
   }

   const cv::Rect& rect = target.GetRegion().Get();
   cv::line(scene.image, Point2f(rect.x, rect.y), Point2f(rect.x + rect.width, rect.y), cv::Scalar(255, 0, 0), 4);
   cv::line(scene.image, Point2f(rect.x + rect.width, rect.y), Point2f(rect.x + rect.width, rect.y + rect.height), cv::Scalar(255, 0, 0), 4);
   cv::line(scene.image, Point2f(rect.x + rect.width, rect.y + rect.height), Point2f(rect.x, rect.y + rect.height), cv::Scalar(255, 0, 0), 4);
   cv::line(scene.image, Point2f(rect.x, rect.y + rect.height), Point2f(rect.x, rect.y), cv::Scalar(255, 0, 0), 4);

   cv::Point2f border(WINDOWS_BORDER_SIZE, WINDOWS_BORDER_SIZE);
   min -= border; max += border;
   if(min.x < 0) min.x = 0;
   if(min.y < 0) min.y = 0;
   if(max.x > scene.image.cols) max.x = scene.image.cols;
   if(max.y > scene.image.rows) max.y = scene.image.rows;

   target.SetRegion(avr::BRect<int>(min, max));
}

} // namespace avr
